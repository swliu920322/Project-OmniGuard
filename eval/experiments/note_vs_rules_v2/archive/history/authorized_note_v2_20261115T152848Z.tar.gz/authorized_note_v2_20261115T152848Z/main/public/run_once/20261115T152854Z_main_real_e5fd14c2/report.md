# Formal evaluation, suite `main`: 20261115T152854Z_main_real_e5fd14c2

Status **completed** (completed all planned calls); mode real; counts as a measurement: False (frozen acceptance file: False).
Prompt B-1.0 `9247896719b66e13…`; spec 1.0; repo head `1eddd79df16e`; tag `eval-note-v2-r3-final-20261115`.
Record-level results are private and not published; their hashes are in the JSON. Aggregates only. Not used for tuning in this round.

**Main figure: accuracy 180/180 = 1.0 (95 % Wilson [0.9791, 1.0]); macro-F1 1.0; errors 0, invalid 0, interrupted 0.**
Next to it, not instead of it: among calls that returned a usable reply 180/180 = 1.0 ([0.9791, 1.0]).

| Class | Support | Precision | Recall | F1 |
|---|---:|---:|---:|---:|
| `NORMAL_NAV` | 60 | 1.0 | 1.0 | 1.0 |
| `CRITICAL_OBSTACLE` | 64 | 1.0 | 1.0 | 1.0 |
| `LOW_BATTERY` | 16 | 1.0 | 1.0 | 1.0 |
| `OVERHEAT` | 20 | 1.0 | 1.0 | 1.0 |
| `LOW_HEALTH` | 12 | 1.0 | 1.0 | 1.0 |
| `OVERSPEED` | 8 | 1.0 | 1.0 | 1.0 |

| System | Primary accuracy | Macro-F1 | Note status | missed_halt | needless_halt |
|---|---:|---:|---:|---:|---:|
| Baseline B | 180/180 = 1.0 | 1.0 | 173/180 | 0 | 0 |
| R1 | 131/180 = 0.7278 | 0.7748 | 60/180 | 31 | 8 |
| R2 | 116/180 = 0.6444 | 0.6817 | 41/180 | 28 | 21 |

Note status of baseline B (noted records, separate): per status recall {'AFFIRMED_CURRENT': {'support': 30, 'recall': 1.0}, 'NEGATED': {'support': 30, 'recall': 1.0}, 'HISTORICAL': {'support': 30, 'recall': 0.8}, 'HYPOTHETICAL': {'support': 30, 'recall': 0.9667}, 'UNCERTAIN': {'support': 30, 'recall': 1.0}, 'IRRELEVANT': {'support': 30, 'recall': 1.0}}
Safety of baseline B: {'n': 180, 'missed_halt': 0, 'needless_halt': 0, 'floor_override': 28, 'floor_override_rate': 0.1556, 'parse_failure_halts': 0, 'fault_halts': 0, 'executed_motion': {'HALT': 96, 'MOVE': 76, 'MOVE_LIMITED': 8}}
